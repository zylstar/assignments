import UIKit

var greeting = "Hello, playground"

var testClosure = {
    print ("iOS")
    
}
testClosure ()

